//The console object in Node.js is used to print information to the terminal. It provides various methods like console.log(), console.error(), and console.warn() to output messages, errors, and warnings. This is especially useful for debugging purposes and logging server activity.
// console_example.js

// Log different types of messages
console.log('This is a general log message.');
console.info('This is an info message.');
console.warn('This is a warning message.');
console.error('This is an error message.');

// Use console to output an object
const user = { name: 'Alice', age: 25, occupation: 'Developer' };
console.log('User object:', user);

// Measure execution time of a code block
console.time('Loop time');
for (let i = 0; i < 1000000; i++) {
    // Simulate some time-consuming task
}
console.timeEnd('Loop time');