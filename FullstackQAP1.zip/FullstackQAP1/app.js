// Import the moment module
const moment = require('moment');

// Get the current date and time
const now = moment();

// Format the current date and time
console.log('Current Date and Time:', now.format('MMMM Do YYYY, h:mm:ss a'));

// Calculate and display a date 7 days from now
const futureDate = now.add(7, 'days');
console.log('Date 7 days from now:', futureDate.format('MMMM Do YYYY, h:mm:ss a'));

// Calculate and display a date 2 weeks ago
const pastDate = now.subtract(2, 'weeks');
console.log('Date 2 weeks ago:', pastDate.format('MMMM Do YYYY, h:mm:ss a'));

// Display the day of the week for the current date
console.log('Today is:', now.format('dddd'));

// Commenting to explain the code:
// - moment() creates a moment object with the current date and time.
// - format() formats the date into a human-readable string.
// - add() and subtract() are used to manipulate the date by adding or subtracting time units like days or weeks.