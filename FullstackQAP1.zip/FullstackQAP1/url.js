//The url module in Node.js provides utilities for URL resolution and parsing. It allows you to work with URLs by breaking them down into their constituent parts, such as the protocol, hostname, pathname, and query string. This module is particularly useful for handling and manipulating URLs in web applications.
// url_example.js

// Import the url module
const url = require('url');

// Sample URL to parse
const sampleUrl = 'http://www.example.com:8080/path/name?query=test#hash';

// Parse the URL
const parsedUrl = url.parse(sampleUrl, true);

// Log the parsed URL object
console.log('Parsed URL object:', parsedUrl);

// Extract and log specific parts of the URL
console.log('Protocol:', parsedUrl.protocol);
console.log('Host:', parsedUrl.host);
console.log('Port:', parsedUrl.port);
console.log('Pathname:', parsedUrl.pathname);
console.log('Query:', parsedUrl.query);
console.log('Hash:', parsedUrl.hash);