//The http module in Node.js allows you to create and manage HTTP servers and clients. It provides the necessary tools to handle HTTP requests and responses, making it ideal for building web applications. Using the http object, you can create a basic server, define routes, and serve content to clients.

// http_example.js

// Import the http module
const http = require('http');

// Create an HTTP server
const server = http.createServer((req, res) => {
    // Set the response HTTP header with status and Content-Type
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    // Send the response body "Hello, HTTP!"
    res.end('Hello, HTTP!\n');
});

// Server listens on port 3000
server.listen(3000, () => {
    console.log('HTTP server running at http://localhost:3000/');
});

